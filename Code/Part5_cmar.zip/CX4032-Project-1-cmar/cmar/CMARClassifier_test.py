from cmar.CMAR_Classifier import *
from cmar.CR_Tree import *
from cmar.FP_tree import *
from cbaLib.pre_processing import *
from cbaLib.validation import *
from cbaLib.ruleitem import RuleItem
from ordered_set import OrderedSet

import csv
MINSUP = 10
MINCONF = 0.65
rules = []

"""
for the following dataset, the rules mined are as follows:
unpruned:
rule:  {'c1', 'a1', 'b2'} -> B :  sup:  50 conf:  1.0
rule:  {'a1', 'c3', 'b1'} -> C :  sup:  60 conf:  1.0
rule:  {'c1', 'a2', 'b1'} -> B :  sup:  100 conf:  1.0
rule:  {'c2', 'a1', 'b1'} -> A :  sup:  150 conf:  1.0
rule:  {'c1', 'a1', 'b1'} -> A :  sup:  80 conf:  0.8
rule:  {'c1', 'b1'} -> B :  sup:  100 conf:  1.0
rule:  {'c1', 'a1', 'b1'} -> A :  sup:  80 conf:  0.8
rule:  {'a1', 'b1'} -> A :  sup:  230 conf:  0.7419354838709677


pruned:
rule:  {'c1', 'a1', 'b2'} -> B :  sup:  50 conf:  1.0
rule:  {'a1', 'c3', 'b1'} -> C :  sup:  60 conf:  1.0
rule:  {'c2', 'a1', 'b1'} -> A :  sup:  150 conf:  1.0
rule:  {'c1', 'b1'} -> B :  sup:  100 conf:  1.0
rule:  {'a1', 'b1'} -> A :  sup:  230 conf:  0.7419354838709677
"""
def read_data(path):
    data = []
    with open(path, 'r') as csv_file:
        reader = csv.reader(csv_file, delimiter=',')
        for line in reader:
            data.append(line)
        while [] in data:
            data.remove([])
    return data

def read_scheme(path):
    with open(path, 'r') as csv_file:
        reader = csv.reader(csv_file, delimiter=',')
        attributes = next(reader)
        value_type = next(reader)
    return attributes, value_type

def convert_to_dataentry_and_build_tree(data, scheme):
    dataentries = []
    items = []
    for index, char in enumerate(data[:-1]):
        items.append(str(scheme[index]) + '' + char)
    dataentry = DataEntry(items, {data[-1]: 1}, 1)
    dataentries.append(dataentry)
    root, head_table = createFPtree(dataentries, minSup=MINSUP)
    print(head_table)
    root.display()


def convert_ruleitem_to_ours(l_ruleitem:RuleItem, scheme):
    support = l_ruleitem.rule_sup_count
    label = l_ruleitem.class_label
    confidence = l_ruleitem.confidence
    items = OrderedSet()
    for cond in l_ruleitem.cond_set:
        attribute = scheme[0][cond]
        value = l_ruleitem.cond_set[cond]
        items.add(attribute+str(value))
    return RuleEntry(items, label, support, confidence)

def convert_data_to_dataentry(l_data, scheme):
    attributes = scheme[0]
    items = []
    for index, i in enumerate(l_data[:-1]):
        item = attributes[index] + str(i)
        items.append(item)
    label = l_data[-1]
    return DataEntry(items, {label:1}, 1)

def get_error(classifier, dataentries: [DataEntry]):
    error_count = 0
    result_counter = {}
    for dataentry in dataentries:
        label = [key for key in dataentry.label][0]
        result = classifier.classify(dataentry)
        if result in result_counter:
            result_counter[result] += 1
        else:
            result_counter[result] = 1
        result_counter[result] += 1
        if result != label:
            error_count += 1
    print(result_counter)
    print("error count is", error_count)
    return error_count/len(dataentries)
# get rules from dataset
def get_rules(data, MINSUP):
    myFPtree, myHeaderTab = createFPtree(data, {}, minSup=MINSUP)
    print("my header_table is ", myHeaderTab)
    myFPtree.display()
    freqItems = []
    rules = []
    mineFPtree(myFPtree, myHeaderTab, MINSUP, set([]), freqItems, rules)
    return rules

def test_read_data(data_path, scheme_path, minsup=MINSUP, minconf=MINCONF):
    data, attributes, value_type = read(data_path, scheme_path)
    # data example ['vhigh', 'vhigh', '2', '2', 'small', 'low', 'unacc']
    # random.shuffle(data)
    dataset = pre_process(data, attributes, value_type)
    # dataset example [4, 1, 4, 2, 1, 1, 'acc']

    scheme = read_scheme(scheme_path)
    print(scheme)


    block_size = int(len(dataset) / 10)
    split_point = [k * block_size for k in range(0, 10)]
    split_point.append(len(dataset))
    running_times = len(split_point) - 1
    running_times = 1
    for k in range(running_times):
        print("\nRound %d:" % k)
    #
        training_dataset = dataset[:split_point[k]] + dataset[split_point[k+1]:]

        train_dataset_to_feed = []
        for data in training_dataset:
            train_dataset_to_feed.append(convert_data_to_dataentry(data, scheme))
        print("dataentry example is")
        train_dataset_to_feed[0].display()
        test_dataset = dataset[split_point[k]:split_point[k+1]]
        test_dataset_to_feed = []
        for data in test_dataset:
            dataentry = convert_data_to_dataentry(data, scheme)
            test_dataset_to_feed.append(dataentry)
        rules = get_rules(train_dataset_to_feed, MINSUP)
        cr_rule_list = rules
        print('rule example is')
        cr_rule_list[0].display()
        """
            newly added pruning functions
            """
        # prune by establishing the cr tree

    root, header_table = createCRtree(cr_rule_list)
    # may figure out a way to perform pruning by coverage in-place of a tree
    # but in this way we cannot order rules in the tree
    # so just pull 'em out and order
    tree_pruned_rules = root.getAllRules(header_table)
    retained_rules, default_label = pruneByCoverage(train_dataset_to_feed, tree_pruned_rules)
    classifier = CMARClassifier(tree_pruned_rules, default_label, train_dataset_to_feed, len(train_dataset_to_feed))
    # classifier = CMARClassifier(cr_rule_list, default_class, train_dataset_to_feed, len(train_dataset_to_feed))
    print(get_error(classifier, test_dataset_to_feed))
    print(len(test_dataset_to_feed), len(train_dataset_to_feed))
    print('default class is', default_label)
    print("rule number is ", len(tree_pruned_rules))
def test():
    data_name = 'car'
    test_data_path = f'C:/Users/yunxing/PycharmProjects/CMAR/cbaLib/datasets/{data_name}.data'.format(data_name=data_name)
    test_scheme_path = 'C:/Users/yunxing/PycharmProjects/CMAR/cbaLib/datasets/{data_name}.names'.format(data_name=data_name)
    test_read_data(test_data_path, test_scheme_path)

test()