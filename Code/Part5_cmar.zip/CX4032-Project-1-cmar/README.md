# CX4032 CMAR Implementation
This branch is a CMAR implementaion from scratch. The following command can be used 
to run the code for a testing dataset **car**.

```cmd
python CMARClassifier_test.py
```
Parameters such as **MINSUP, MINCONF** can be directly adjusted in code. 
