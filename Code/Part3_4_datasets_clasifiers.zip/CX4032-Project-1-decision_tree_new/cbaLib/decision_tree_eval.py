"""
Description: This is our experimental code. We provide 4 test modes for experiments:
    10-fold cross-validations on CBA (M1) without pruning
    10-fold cross-validations on CBA (M1) with pruning
    10-fold cross-validations on CBA (M2) without pruning
    10-fold cross-validations on CBA (M2) with pruning
Input: the relative directory path of data file and scheme file
Output: the experimental results (similar to Table 1: Experiment Results in this paper)
Author: CBA Studio
"""
from sklearn.datasets import load_wine
import category_encoders as ce
import pandas as pd
from scipy.sparse import data
from sklearn import preprocessing 
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn import metrics
from read import read
from pre_processing import pre_process
from cba_rg import rule_generator
from cba_cb_m1 import classifier_builder_m1
from cba_cb_m1 import is_satisfy
from cba_cb_m2 import classifier_builder_m2
from cba_cb_m2_songyus_implementation import build_m2
import time
import random
from sklearn.model_selection import train_test_split

from sklearn.metrics import accuracy_score, log_loss
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC, LinearSVC, NuSVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, GradientBoostingClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis
from xgboost import XGBClassifier
import xgboost

# calculate the error rate of the classifier on the dataset
def get_error_rate(classifier, dataset):
    size = len(dataset)
    error_number = 0
    for case in dataset:
        is_satisfy_value = False
        for rule in classifier.rule_list:
            is_satisfy_value = is_satisfy(case, rule)
            if is_satisfy_value == True:
                break
        if is_satisfy_value == False:
            if classifier.default_class != case[-1]:
                error_number += 1
    return error_number / size


# 10-fold cross-validations on CBA (M1) without pruning
def cross_validate_m1_without_prune(data_path, scheme_path, minsup=0.01, minconf=0.5):
    data, attributes, value_type = read(data_path, scheme_path)
    random.shuffle(data)
    dataset = pre_process(data, attributes, value_type)

    block_size = int(len(dataset) / 10)
    split_point = [k * block_size for k in range(0, 10)]
    split_point.append(len(dataset))

    cba_rg_total_runtime = 0
    cba_cb_total_runtime = 0
    total_car_number = 0
    total_classifier_rule_num = 0
    error_total_rate = 0

    for k in range(len(split_point)-1):
        print("\nRound %d:" % k)

        training_dataset = dataset[:split_point[k]
                                   ] + dataset[split_point[k+1]:]
        test_dataset = dataset[split_point[k]:split_point[k+1]]

        start_time = time.time()
        cars = rule_generator(training_dataset, minsup, minconf)
        end_time = time.time()
        cba_rg_runtime = end_time - start_time
        cba_rg_total_runtime += cba_rg_runtime

        start_time = time.time()
        classifier_m1 = classifier_builder_m1(cars, training_dataset)
        end_time = time.time()
        cba_cb_runtime = end_time - start_time
        cba_cb_total_runtime += cba_cb_runtime

        error_rate = get_error_rate(classifier_m1, test_dataset)
        error_total_rate += error_rate

        total_car_number += len(cars.rules)
        total_classifier_rule_num += len(classifier_m1.rule_list)

        print("CBA's error rate without pruning: %.1lf%%" % (error_rate * 100))
        print("No. of CARs without pruning: %d" % len(cars.rules))
        print("CBA-RG's run time without pruning: %.2lf s" % cba_rg_runtime)
        print("CBA-CB M1's run time without pruning: %.2lf s" % cba_cb_runtime)
        print("No. of rules in classifier of CBA-CB M1 without pruning: %d" %
              len(classifier_m1.rule_list))

    print("\nAverage CBA's error rate without pruning: %.1lf%%" %
          (error_total_rate / 10 * 100))
    print("Average No. of CARs without pruning: %d" %
          int(total_car_number / 10))
    print("Average CBA-RG's run time without pruning: %.2lf s" %
          (cba_rg_total_runtime / 10))
    print("Average CBA-CB M1's run time without pruning: %.2lf s" %
          (cba_cb_total_runtime / 10))
    print("Average No. of rules in classifier of CBA-CB M1 without pruning: %d" %
          int(total_classifier_rule_num / 10))


# 10-fold cross-validations on CBA (M1) with pruning
def cross_validate_m1_with_prune(data_path, scheme_path, minsup=0.01, minconf=0.5):
    data, attributes, value_type = read(data_path, scheme_path)
    random.shuffle(data)
    dataset = pre_process(data, attributes, value_type)

    block_size = int(len(dataset) / 10)
    split_point = [k * block_size for k in range(0, 10)]
    split_point.append(len(dataset))

    cba_rg_total_runtime = 0
    cba_cb_total_runtime = 0
    total_car_number = 0
    total_classifier_rule_num = 0
    error_total_rate = 0

    for k in range(len(split_point)-1):
        print("\nRound %d:" % k)

        training_dataset = dataset[:split_point[k]
                                   ] + dataset[split_point[k+1]:]
        test_dataset = dataset[split_point[k]:split_point[k+1]]

        start_time = time.time()
        cars = rule_generator(training_dataset, minsup, minconf)
        cars.prune_rules(training_dataset)
        cars.rules = cars.pruned_rules
        end_time = time.time()
        cba_rg_runtime = end_time - start_time
        cba_rg_total_runtime += cba_rg_runtime

        start_time = time.time()
        classifier_m1 = classifier_builder_m1(cars, training_dataset)
        end_time = time.time()
        cba_cb_runtime = end_time - start_time
        cba_cb_total_runtime += cba_cb_runtime

        error_rate = get_error_rate(classifier_m1, test_dataset)
        error_total_rate += error_rate

        total_car_number += len(cars.rules)
        total_classifier_rule_num += len(classifier_m1.rule_list)

        print("CBA's error rate with pruning: %.1lf%%" % (error_rate * 100))
        print("No. of CARs with pruning: %d" % len(cars.rules))
        print("CBA-RG's run time with pruning: %.2lf s" % cba_rg_runtime)
        print("CBA-CB M1's run time with pruning: %.2lf s" % cba_cb_runtime)
        print("No. of rules in classifier of CBA-CB M1 with pruning: %d" %
              len(classifier_m1.rule_list))

    print("\nAverage CBA's error rate with pruning: %.1lf%%" %
          (error_total_rate / 10 * 100))
    print("Average No. of CARs with pruning: %d" % int(total_car_number / 10))
    print("Average CBA-RG's run time with pruning: %.2lf s" %
          (cba_rg_total_runtime / 10))
    print("Average CBA-CB M1's run time with pruning: %.2lf s" %
          (cba_cb_total_runtime / 10))
    print("Average No. of rules in classifier of CBA-CB M1 with pruning: %d" %
          int(total_classifier_rule_num / 10))


# 10-fold cross-validations on CBA (M2) without pruning
def cross_validate_m2_without_prune(data_path, scheme_path, minsup=0.01, minconf=0.5):
    data, attributes, value_type = read(data_path, scheme_path)
    random.shuffle(data)
    dataset = pre_process(data, attributes, value_type)

    block_size = int(len(dataset) / 10)
    split_point = [k * block_size for k in range(0, 10)]
    split_point.append(len(dataset))

    cba_rg_total_runtime = 0
    cba_cb_total_runtime = 0
    total_car_number = 0
    total_classifier_rule_num = 0
    error_total_rate = 0

    for k in range(len(split_point)-1):
        print("\nRound %d:" % k)

        training_dataset = dataset[:split_point[k]
                                   ] + dataset[split_point[k+1]:]
        test_dataset = dataset[split_point[k]:split_point[k+1]]

        start_time = time.time()
        cars = rule_generator(training_dataset, minsup, minconf)
        end_time = time.time()
        cba_rg_runtime = end_time - start_time
        cba_rg_total_runtime += cba_rg_runtime

        start_time = time.time()
        classifier_m2 = classifier_builder_m2(cars, training_dataset)
        end_time = time.time()
        cba_cb_runtime = end_time - start_time
        cba_cb_total_runtime += cba_cb_runtime

        error_rate = get_error_rate(classifier_m2, test_dataset)
        error_total_rate += error_rate

        total_car_number += len(cars.rules)
        total_classifier_rule_num += len(classifier_m2.rule_list)
        print("CBA's error rate without pruning: %.1lf%%" % (error_rate * 100))
        print("No. of CARs without pruning: %d" % len(cars.rules))
        print("CBA-RG's run time without pruning: %.2lf s" % cba_rg_runtime)
        print("CBA-CB M2's run time without pruning: %.2lf s" % cba_cb_runtime)
        print("No. of rules in classifier of CBA-CB M2 without pruning: %d" %
              len(classifier_m2.rule_list))

    print("\nAverage CBA's error rate without pruning: %.1lf%%" %
          (error_total_rate / 10 * 100))
    print("Average No. of CARs without pruning: %d" %
          int(total_car_number / 10))
    print("Average CBA-RG's run time without pruning: %.2lf s" %
          (cba_rg_total_runtime / 10))
    print("Average CBA-CB M2's run time without pruning: %.2lf s" %
          (cba_cb_total_runtime / 10))
    print("Average No. of rules in classifier of CBA-CB M2 without pruning: %d" %
          int(total_classifier_rule_num / 10))


# 10-fold cross-validations on CBA (M2) with pruning
def cross_validate_m2_with_prune(data_path, scheme_path, minsup=0.01, minconf=0.5):
    data, attributes, value_type = read(data_path, scheme_path)
    random.shuffle(data)
    dataset = pre_process(data, attributes, value_type)

    block_size = int(len(dataset) / 10)
    split_point = [k * block_size for k in range(0, 10)]
    split_point.append(len(dataset))

    cba_rg_total_runtime = 0
    cba_cb_total_runtime = 0
    total_car_number = 0
    total_classifier_rule_num = 0
    error_total_rate = 0

    for k in range(len(split_point)-1):
        print("\nRound %d:" % k)

        training_dataset = dataset[:split_point[k]
                                   ] + dataset[split_point[k+1]:]
        test_dataset = dataset[split_point[k]:split_point[k+1]]

        start_time = time.time()
        cars = rule_generator(training_dataset, minsup, minconf)
        cars.prune_rules(training_dataset)
        cars.rules = cars.pruned_rules
        end_time = time.time()
        cba_rg_runtime = end_time - start_time
        cba_rg_total_runtime += cba_rg_runtime

        start_time = time.time()
        classifier_m2 = classifier_builder_m2(cars, training_dataset)
        end_time = time.time()
        cba_cb_runtime = end_time - start_time
        cba_cb_total_runtime += cba_cb_runtime

        error_rate = get_error_rate(classifier_m2, test_dataset)
        error_total_rate += error_rate

        total_car_number += len(cars.rules)
        total_classifier_rule_num += len(classifier_m2.rule_list)

        print("CBA's error rate with pruning: %.1lf%%" % (error_rate * 100))
        print("No. of CARs without pruning: %d" % len(cars.rules))
        print("CBA-RG's run time with pruning: %.2lf s" % cba_rg_runtime)
        print("CBA-CB M2's run time with pruning: %.2lf s" % cba_cb_runtime)
        print("No. of rules in classifier of CBA-CB M2 with pruning: %d" %
              len(classifier_m2.rule_list))

    print("\nAverage CBA's error rate with pruning: %.1lf%%" %
          (error_total_rate / 10 * 100))
    print("Average No. of CARs with pruning: %d" % int(total_car_number / 10))
    print("Average CBA-RG's run time with pruning: %.2lf s" %
          (cba_rg_total_runtime / 10))
    print("Average CBA-CB M2's run time with pruning: %.2lf s" %
          (cba_cb_total_runtime / 10))
    print("Average No. of rules in classifier of CBA-CB M2 with pruning: %d" %
          int(total_classifier_rule_num / 10))


def cross_validate_m2_songyus_implementation_with_prune(data_path, scheme_path, minsup=0.01, minconf=0.5):
    data, attributes, value_type = read(data_path, scheme_path)
    random.shuffle(data)
    dataset = pre_process(data, attributes, value_type)

    block_size = int(len(dataset) / 10)
    split_point = [k * block_size for k in range(0, 10)]
    split_point.append(len(dataset))

    cba_rg_total_runtime = 0
    cba_cb_total_runtime = 0
    total_car_number = 0
    total_classifier_rule_num = 0
    error_total_rate = 0

    for k in range(len(split_point)-1):
        print("\nRound %d:" % k)

        training_dataset = dataset[:split_point[k]
                                   ] + dataset[split_point[k+1]:]
        test_dataset = dataset[split_point[k]:split_point[k+1]]

        start_time = time.time()
        cars = rule_generator(training_dataset, minsup, minconf)
        cars.prune_rules(training_dataset)
        cars.rules = cars.pruned_rules
        end_time = time.time()
        cba_rg_runtime = end_time - start_time
        cba_rg_total_runtime += cba_rg_runtime

        start_time = time.time()
        classifier_m2_songyus_ver = build_m2(cars, training_dataset)
        end_time = time.time()
        cba_cb_runtime = end_time - start_time
        cba_cb_total_runtime += cba_cb_runtime

        error_rate = classifier_m2_songyus_ver.get_error_rate(test_dataset)
        error_total_rate += error_rate

        total_car_number += len(cars.rules)
        total_classifier_rule_num += len(
            classifier_m2_songyus_ver.rule_records)

        print("CBA's error rate with pruning: %.1lf%%" % (error_rate * 100))
        print("No. of CARs without pruning: %d" % len(cars.rules))
        print("CBA-RG's run time with pruning: %.2lf s" % cba_rg_runtime)
        print("CBA-CB M2's run time with pruning: %.2lf s" % cba_cb_runtime)
        print("No. of rules in classifier of CBA-CB M2 with pruning: %d" %
              len(classifier_m2_songyus_ver.rule_records))

    print("\nAverage CBA's error rate with pruning: %.1lf%%" %
          (error_total_rate / 10 * 100))
    print("Average No. of CARs with pruning: %d" % int(total_car_number / 10))
    print("Average CBA-RG's run time with pruning: %.2lf s" %
          (cba_rg_total_runtime / 10))
    print("Average CBA-CB M2's run time with pruning: %.2lf s" %
          (cba_cb_total_runtime / 10))
    print("Average No. of rules in classifier of CBA-CB M2 with pruning: %d" %
          int(total_classifier_rule_num / 10))

def iris_decision_tree(data_path, scheme_path):
    data, attributes, value_type = read(data_path, scheme_path)
    random.shuffle(data)
    dataset = pre_process(data, attributes, value_type)
        
    train = [sublist[:4] for sublist in dataset]
    targets = [sublist[4:] for sublist in dataset]
    label_encoder = preprocessing.LabelEncoder() 
    targets = label_encoder.fit_transform(targets)

    #on trainX and targetX only..
    X_train, test_x, y_train, test_lab = train_test_split(
        train, targets, test_size=0.4, random_state=42
    )
    clf = DecisionTreeClassifier(max_depth=3, random_state=42)
    clf.fit(X_train, y_train)
    test_pred_decision_tree = clf.predict(test_x)
    print("accuracy of decision tree ",metrics.accuracy_score(test_lab, test_pred_decision_tree))
    print(metrics.classification_report(test_lab, test_pred_decision_tree))
    test(train,targets)
def ionosphere_preprocess():
      names = [str(i) for i in range(34)]
      names.append("target")

      inputData = pd.read_csv("./datasets/ionosphere.data", names=names)
      targetEncoded = []
      for i in range(len(inputData["target"].values)):
            if inputData["target"].values[i] == "g":
                  value = 1
            else:
                  value = 0
            targetEncoded.append(value)
      inputData["target_encoded"] = targetEncoded
      inputData.drop(["target"], axis=1, inplace=True)
      y = inputData["target_encoded"].values
      X = inputData.copy(deep=True)
      X.drop(["target_encoded"], axis=1, inplace=True)
      test(X,y)

def car_decision_tree():
      csv = './datasets/car.data'
      df = pd.read_csv(csv)
      col_names = ['buying', 'maint', 'doors', 'persons', 'lug_boot', 'safety', 'class']
      df.columns = col_names
      X = df.drop(['class'], axis=1)
      y = df['class']
     
      X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.4, random_state=0)
      encoder = ce.OrdinalEncoder(cols=['buying', 'maint', 'doors', 'persons', 'lug_boot', 'safety'])
      X_train = encoder.fit_transform(X_train)
      X_test = encoder.transform(X_test)
     # clf = DecisionTreeClassifier(max_depth =3,random_state=0)
      # dt = DecisionTreeClassifier(min_samples_split=20,max_depth=5,random_state=99)
      test2(X_train, X_test, y_train, y_test)
def zoo_decision_tree():
      csv = './datasets/zoo.csv'
      df = pd.read_csv(csv)
      #print(df.head())
      y=df['class_type'].values
      X=df.drop(['class_type','animal_name'],axis=1).values
      X_train,X_test,y_train,y_test = train_test_split(X, y, test_size=0.3, random_state=42)
      knn = KNeighborsClassifier(n_neighbors=7)
      knn.fit(X_train,y_train)
      print(knn.score(X_train,y_train))
      test(X,y)
      

def heart_decision_tree():
      csv = './datasets/heart.csv'
      df = pd.read_csv(csv)
      X = df.iloc[:,0:13] # Features
      y = df.iloc[:,13] # Target variable
      X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=1) # 70% training and 30% test
      # Create Decision Tree classifer object
      clf = DecisionTreeClassifier()
      # Train Decision Tree Classifer
      clf = clf.fit(X_train,y_train)
      #Predict the response for test dataset
      y_pred = clf.predict(X_test)

      print("accuracy of decision tree ",metrics.accuracy_score(y_test, y_pred))
      print(metrics.classification_report(y_test, y_pred))
      test(X,y)
      #print("Accuracy:",metrics.accuracy_score(y_test, y_pred))
def test(x, y):
      X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.3, random_state=1)
      classifiers = [
            KNeighborsClassifier(3),
            SVC(kernel="rbf", C=0.025, probability=True),
            #NuSVC(probability=True),
            DecisionTreeClassifier(max_depth =3,random_state=0),
            RandomForestClassifier(),
            XGBClassifier(),
            AdaBoostClassifier(),
            GradientBoostingClassifier(),
            GaussianNB(),
            LinearDiscriminantAnalysis()]
            #QuadraticDiscriminantAnalysis()]
      log_cols=["Classifier", "Accuracy", "Log Loss"]
      log = pd.DataFrame(columns=log_cols)

      for clf in classifiers:
            clf.fit(X_train, y_train)
            name = clf.__class__.__name__

            print("="*30)
            print(name)

            print('****Results****')
            train_predictions = clf.predict(X_test)
            acc = accuracy_score(y_test, train_predictions)
            print("Accuracy: {:.4%}".format(acc))

            train_predictions = clf.predict_proba(X_test)
            #ll = log_loss(y_test, train_predictions)
            #print("Log Loss: {}".format(ll))

            log_entry = pd.DataFrame([[name, acc*100, 99]], columns=log_cols)
            log = log.append(log_entry)
    
      print("="*30)
#to pass in data already split
def test2(X_train, X_test, y_train, y_test):
     # X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=0)
      classifiers = [
            KNeighborsClassifier(3),
            SVC(kernel="rbf", C=0.025, probability=True),
           # NuSVC(probability=True),
            DecisionTreeClassifier(),
            RandomForestClassifier(),
            XGBClassifier(),
            AdaBoostClassifier(),
            GradientBoostingClassifier(),
            GaussianNB(),
            LinearDiscriminantAnalysis(),
            QuadraticDiscriminantAnalysis()]
      log_cols=["Classifier", "Accuracy", "Log Loss"]
      log = pd.DataFrame(columns=log_cols)

      for clf in classifiers:
            clf.fit(X_train, y_train)
            name = clf.__class__.__name__

            print("="*30)
            print(name)

            print('****Results****')
            train_predictions = clf.predict(X_test)
            acc = accuracy_score(y_test, train_predictions)
            print("Accuracy: {:.4%}".format(acc))

            #train_predictions = clf.predict_proba(X_test)
            ll = 0
            print("Log Loss: {}".format(ll))

            log_entry = pd.DataFrame([[name, acc*100, ll]], columns=log_cols)
            log = log.append(log_entry)
    
      print("="*30)
def wine_test():
      dataset = load_wine()
      X = dataset.data
      y = dataset.target
      test(X,y)
# test entry goes here
if __name__ == "__main__":
    # using the relative path, all data sets are stored in datasets directory
    test_data_path = './datasets/iris.data'
    test_scheme_path = './datasets/iris.names'

    # just choose one mode to experiment by removing one line comment and running
    # cross_validate_m1_without_prune(test_data_path, test_scheme_path)
    # cross_validate_m1_with_prune(test_data_path, test_scheme_path)
    #cross_validate_m2_without_prune(test_data_path, test_scheme_path)
    #cross_validate_m2_with_prune(test_data_path, test_scheme_path)
    # cross_validate_m2_songyus_implementation_with_prune(
    #     test_data_path, test_scheme_path)
    #iris_decision_tree(test_data_path,test_scheme_path)
    #heart_decision_tree()
    #car_decision_tree()
    #heart_decision_tree()
    #iris_decision_tree(test_data_path,test_scheme_path)
    #ionosphere_preprocess()
    #zoo_decision_tree()
    wine_test()

