"""
Description: This file implements a classifier builder using the
    CBA-CB: M2 algorithm, which covers each case in the dataset
    using the best rule found.
Input: A set of CARs generated from rule_generator(see cab_rg.py)
    and a preprocessed dataset (see pre_processing.py)
Output: A classifier built based on the input CARs and a
    corresponding dataset.
Author: Song Yu
References:
- Bing Liu, Wynne Hsu, Yiming Ma:Integrating Classification and
    Association Rule Mining. KDD 1998: 80-86;
- CBA Studio
"""

from ruleitem import RuleItem
from cba_cb_m1 import sort
from functools import cmp_to_key


class Classifier:
    def __init__(self):
        # list of (rule, default-class, totalErrors)
        self.rule_records = []
        self.default_class = None

    # add a new rule record that might contain the final candidate
    # record: <rule, default_class, total_errors>
    def append_rule_record(self, new_rule_record):
        self.rule_records.append(new_rule_record)

    # updates the default_class
    def set_default_class(self, new_default_class):
        self.default_class = new_default_class

    # line 18 - 20
    # Find the first rule p in C with the lowest totalErrors,
    # and then discard all the rules after p from C
    # record: <rule, default_class, total_errors>
    def discard_useless_rules(self):
        min_total_errors = min([rule_record[2]
                                for rule_record in self.rule_records])
        target_idx = None
        for idx in range(len(self.rule_records)):
            if self.rule_records[idx][2] == min_total_errors:
                target_idx = idx
        # set the default class to that of the target rule
        self.default_class = self.rule_records[target_idx][1]
        # remove rules after the target rule
        self.rule_records = self.rule_records[:(target_idx+1)]

    # get the error rate of this classifier given a dataset
    def get_error_rate(self, dataset):
        dataset_size = len(dataset)
        num_of_errors = 0
        rules = [rule_record[0] for rule_record in self.rule_records]
        for case in dataset:
            for rule in rules:
                # the case is not covered by any rule and its class is not equal to the default class
                if rule.covers_case(case) == False and self.default_class != case[-1]:
                    num_of_errors += 1
        return num_of_errors / dataset_size

    # prints the info of this classifier instance
    def getInfo(self):
        print('Rules:')
        for record in self.rule_records:
            record[0].print_rule()
        print('Default Class: ', self.default_class)


class Rule(RuleItem):
    """
    A class inherited from RuleItem.
    Adding a new attribute class_cases_covered and replace field.
    """

    def __init__(self, cond_set, class_label, dataset):
        RuleItem.__init__(self, cond_set, class_label, dataset)
        self._init_class_cases_covered(dataset)
        self.replace = set()
        self.is_marked = False

    def add_replace_record(self, record):
        self.replace.add(record)

    def get_mark_status(self):
        return self.is_marked

    def mark(self):
        self.is_marked = True

    # checks if this rule covers a given case
    def covers_case(self, case):
        # checks if the LHS of rule is aligned with the case
        for item_name in self.cond_set:
            if case[item_name] != self.cond_set[item_name]:
                return None
        case_class = case[-1]
        return True if case_class == self.class_label else False

        # get the number of errors a rule makes
    # (i.e., number of cases this rule cannot cover)
    def get_errors_in_dataset(self, dataset):
        error_count = 0
        for case in dataset:
            if case is not None and self.covers_case(case) == False:
                error_count += 1
        return error_count

    def _init_class_cases_covered(self, dataset):
        class_column = [x[-1] for x in dataset]
        class_label = set(class_column)
        self.class_cases_covered = dict((x, 0) for x in class_label)

    # check if this rule precedes another rule
    def precedes(self, opponent):
        if opponent is None:
            return True
        if self.confidence > opponent.confidence:
            return True
        elif self.confidence < opponent.confidence:
            return False
        else:  # this rule have the same confidence as the opponent
            if self.support > opponent.support:
                return True
            elif self.support < opponent.support:
                return False
            else:  # this rule have the same support as the opponent
                # this rule is generated earlier
                if len(self.cond_set) < len(opponent.cond_set):
                    return True
                else:
                    return False


def ruleitem2rule(rule_item, dataset):
    return Rule(rule_item.cond_set, rule_item.class_label, dataset)


# builds a classifier using cba-cb m2 algorithm
def build_m2(raw_cars, dataset):
    # util functions definitions

    # finds the highest precedence rule that correctly/wrongly covers the case
    # returns the indexes of the cRule and wRule
    def max_cover_rule(cars_list, case):
        c_rule_idx, w_rule_idx = None, None

        for rule_idx in range(len(cars_list)):
            if c_rule_idx is not None and w_rule_idx is not None:
                return c_rule_idx, w_rule_idx
            elif c_rule_idx is None and cars_list[rule_idx].class_label == case[-1]:
                c_rule_idx = rule_idx if cars_list[rule_idx].covers_case(
                    case) else None
            elif w_rule_idx is None and cars_list[rule_idx].class_label != case[-1]:
                # find the highest precedence rule that covers the case in the set
                # of rules that have different class as d
                mistakenly_covered_case = case[:-1]
                mistakenly_covered_case.append(cars_list[rule_idx].class_label)
                w_rule_idx = rule_idx if cars_list[rule_idx].covers_case(
                    mistakenly_covered_case) else None

        return c_rule_idx, w_rule_idx

    # finds all the rules that wrongly classify the dID case and have higher
    # precedences than that of its cRule
    def all_cover_rules(U, cars_list, case, c_rule):
        w_set = set()
        for idx in U:
            rule = cars_list[idx]
            if rule.precedes(c_rule) and rule.covers_case(case) == False:
                w_set.add(idx)

        return w_set

    # counts the number of training cases in each class (line 1) in
    # the initial training data.
    def comp_class_distri(dataset):
        class_distribution = None

        # make sure dataset is not empty
        if not len(dataset):
            return class_distribution

        dataset_copy = dataset.copy()
        # remove empty/null data case, if any
        while [] in dataset_copy:
            dataset_copy.remove([])

        class_col = [case[-1] for case in dataset_copy]
        class_labels = set(class_col)
        # count the number of cases for each class label
        class_distribution = {label: class_col.count(
            label) for label in class_labels}

        return class_distribution

    # sort the set of cRules by precedence
    # returns a list of sorted c_rule_idx
    def sortQ(q, cars_list):
        def cmp_method(i, j):
            if cars_list[i].confidence < cars_list[j].confidence:
                return 1
            elif cars_list[i].confidence == cars_list[j].confidence:
                if cars_list[i].support < cars_list[j].support:
                    return 1
                elif cars_list[i].support == cars_list[j].support:
                    if len(cars_list[i].cond_set) < len(cars_list[j].cond_set):
                        return -1
                    elif len(cars_list[i].cond_set) == len(cars_list[j].cond_set):
                        return 0
                    else:
                        return 1
                else:
                    return -1
            else:
                return -1

        q_list = list(q)
        q_list.sort(key=cmp_to_key(cmp_method))
        return q_list

    # updates the distribution of class labels
    def update_class_distribution(rule, prev_class_distribution):
        class_distribution_copy = prev_class_distribution.copy()

        for covered_case in list(rule.class_cases_covered.keys()):
            class_distribution_copy[covered_case] -= rule.class_cases_covered[covered_case]
        return class_distribution_copy

    # get a default class which is the majority class
    # in the remaining training data
    def select_default(class_distribution):
        if class_distribution is None:
            return None
        default_class_key = max(class_distribution, key=class_distribution.get)
        return default_class_key

    # get the number of errors that the default class will make
    def def_err(default_class, class_distribution):
        if class_distribution is None:
            return None
        num_of_all_class_count = sum(class_distribution.values())
        num_of_default_class_count = class_distribution[default_class]
        return num_of_all_class_count - num_of_default_class_count

    classifier = Classifier()
    cars_list = sort(raw_cars)

    for car_idx in range(len(cars_list)):
        cars_list[car_idx] = ruleitem2rule(cars_list[car_idx], dataset)

    # stage 1
    Q, U, A = set(), set(), set()

    for case_id in range(len(dataset)):
        case = dataset[case_id]
        case_class = case[-1]

        c_rule_idx, w_rule_idx = max_cover_rule(cars_list, case)

        if c_rule_idx is not None:
            U.add(c_rule_idx)
            cars_list[c_rule_idx].class_cases_covered[case_class] += 1

        if c_rule_idx is not None and w_rule_idx is not None:
            if cars_list[c_rule_idx].precedes(cars_list[w_rule_idx]):
                Q.add(c_rule_idx)
                cars_list[c_rule_idx].mark()
            else:
                record = (case_id, case_class, c_rule_idx, w_rule_idx)
                A.add(record)
        elif c_rule_idx is None and w_rule_idx is not None:
            record = (case_id, case_class, c_rule_idx, w_rule_idx)
            A.add(record)

    # stage 2
    for record in A:
        case_id, case_class, c_rule_idx, w_rule_idx = record[0], record[1], record[2], record[3]
        if cars_list[w_rule_idx].get_mark_status():
            if c_rule_idx is not None:
                cars_list[c_rule_idx].class_cases_covered[case_class] -= 1
            cars_list[w_rule_idx].class_cases_covered[case_class] += 1
        else:
            cRule = cars_list[c_rule_idx] if c_rule_idx is not None else None
            w_set = all_cover_rules(
                U, cars_list, dataset[case_id], cRule)
            for _rule_idx in w_set:
                new_record = (c_rule_idx, case_id, case_class)
                cars_list[_rule_idx].add_replace_record(new_record)
                cars_list[_rule_idx].class_cases_covered[case_class] += 1
            Q = Q.union(w_set)

    # stage 3
    class_distribution = comp_class_distri(dataset)
    rule_errors = 0
    q_list = sortQ(Q, cars_list)

    # list to track covered case ids
    covered_cases_ids = []
    for rule_idx in q_list:
        r = cars_list[rule_idx]
        if r.class_cases_covered[r.class_label] != 0:
            for entry in r.replace:
                entry_rul_idx, d_id, y = entry[0], entry[1], entry[2]

                if d_id in covered_cases_ids:
                    cars_list[rule_idx].class_cases_covered[y] -= 1
                else:
                    if entry_rul_idx is not None:
                        cars_list[entry_rul_idx].class_cases_covered[y] -= 1
            # update the covered_cases_ids list
            for case_idx in range(len(dataset)):
                case = dataset[case_idx]
                if case_idx not in covered_cases_ids and case is not None and r.covers_case(case):
                    dataset[case_idx] = None
                    covered_cases_ids.append(case_idx)

            rule_errors += r.get_errors_in_dataset(dataset)
            class_distribution = update_class_distribution(
                r, class_distribution)
            default_class = select_default(class_distribution)
            default_errors = def_err(default_class, class_distribution)
            total_errors = rule_errors + default_errors
            new_rule_record = (r, default_class, total_errors)
            classifier.append_rule_record(new_rule_record)
    # line 18 - 19
    classifier.discard_useless_rules()
    return classifier


# for testing purpose
if __name__ == '__main__':
    import cba_rg

    dataset = [[1, 1, 1], [1, 1, 1], [1, 2, 1], [2, 2, 1], [2, 2, 1],
               [2, 2, 0], [2, 3, 0], [2, 3, 0], [1, 1, 0], [3, 2, 0]]
    minsup = 0.15
    minconf = 0.6
    cars = cba_rg.rule_generator(dataset, minsup, minconf)
    classifier = build_m2(cars, dataset)
    classifier.getInfo()

    print()
    dataset = [[1, 1, 1], [1, 1, 1], [1, 2, 1], [2, 2, 1], [2, 2, 1],
               [2, 2, 0], [2, 3, 0], [2, 3, 0], [1, 1, 0], [3, 2, 0]]
    cars.prune_rules(dataset)
    cars.rules = cars.pruned_rules
    classifier = build_m2(cars, dataset)
    classifier.getInfo()
